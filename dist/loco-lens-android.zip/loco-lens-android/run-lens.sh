#!/usr/bin/env bash
# Start the standalone lens server (taps VNC 127.0.0.1:5901 by default).
set -e
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
export LENS_BACKEND_DIR="$HERE/lens/backend"
export LENS_INSTANCES="${LENS_INSTANCES:-local=127.0.0.1:5901}"
export LENS_PORT="${LENS_PORT:-3001}"
exec node "$HERE/lens/lens-server.js"
