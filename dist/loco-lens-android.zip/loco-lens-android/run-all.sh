#!/usr/bin/env bash
# Boot the golden image (safe512, VNC :5901) and start the lens server.
set -e
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
IMG="${1:-$HOME/loco-runtime/images/win98.qcow2}"
[ -f "$IMG" ] || { echo "ERROR: image not found: $IMG (see install.sh step 1)"; exit 1; }
echo "Booting emulator (VNC 127.0.0.1:5901)..."
bash "$HERE/qemu/qemu-launcher.sh" --disk "$IMG" --profile safe512 \
  --run-dir "$HOME/loco-runtime/run" --vnc-display 1
echo "Starting lens server..."
exec "$HERE/run-lens.sh"
