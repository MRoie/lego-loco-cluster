#!/usr/bin/env bash
# Pull the Win98+Loco golden image from GHCR and place the qcow2 at
# ~/loco-runtime/images/win98.qcow2. Public images pull anonymously; for a
# private image set GHCR_TOKEN (+ optional GHCR_USER, default MRoie).
#
#   bash fetch-image.sh [IMAGE_REF] [DEST_QCOW2]
set -e
IMAGE="${1:-ghcr.io/mroie/lego-loco-cluster/win98-loco-golden:safe512-v1}"
DEST="${2:-$HOME/loco-runtime/images/win98.qcow2}"
mkdir -p "$(dirname "$DEST")"

if [ -f "$DEST" ]; then echo "Image already present: $DEST"; exit 0; fi
if ! command -v skopeo >/dev/null 2>&1; then
  pkg install -y skopeo >/dev/null 2>&1 || { echo "skopeo not available (pkg install skopeo)"; exit 1; }
fi

TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
CREDS=()
[ -n "${GHCR_TOKEN:-}" ] && CREDS=(--src-creds "${GHCR_USER:-MRoie}:${GHCR_TOKEN}")

echo "Pulling $IMAGE (this is ~500 MB)..."
skopeo copy "${CREDS[@]}" --override-os linux "docker://$IMAGE" "oci-archive:$TMP/img.tar"

echo "Extracting qcow2..."
tar -xf "$TMP/img.tar" -C "$TMP"
# Single-layer scratch carrier: the qcow2 layer is by far the largest blob.
LAYER="$(ls -S "$TMP"/blobs/sha256/* 2>/dev/null | head -1)"
[ -n "$LAYER" ] || { echo "no image layers found"; exit 1; }
QC="$(tar -tf "$LAYER" 2>/dev/null | grep -E '\.qcow2(\.builtin)?$' | head -1 || true)"
[ -n "$QC" ] || { echo "no qcow2 in the image layer"; exit 1; }
tar -xf "$LAYER" -C "$TMP" "$QC"
mv "$TMP/$QC" "$DEST"
echo "Placed golden image at $DEST"
