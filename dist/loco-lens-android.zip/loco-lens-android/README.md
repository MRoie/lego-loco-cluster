# Loco Lens — Android (Termux) bundle

Run Windows 98 + Lego Loco under QEMU on your phone and drive an M5Stack
StopWatch "Loco Lens" from it — no cluster, no React app. The VNC is the
full-screen front; the lens server taps the same VNC for the watch crop.

## Install (one command)
```bash
unzip loco-lens-android.zip        # or: tar -xzf loco-lens-android.tar.gz
cd loco-lens-android
bash install.sh
```
Installs QEMU + Node in Termux, the lens-server deps, and downloads the golden
image from GHCR. `bash install.sh --no-image` to skip the download.

> **Important — don't run from `/sdcard` / `Download`.** Android shared storage
> can't create symlinks, so `npm install` fails there (`EACCES symlink`). You do
> NOT need `sudo`. install.sh auto-detects this and copies the bundle to
> `~/loco-lens-android` (Termux's ext4 home) before installing — just re-run it
> from there if prompted, or unzip into `$HOME` to begin with:
> `cd ~ && unzip /sdcard/Download/loco-lens-android.zip && cd loco-lens-android && bash install.sh`

## The image
`install.sh` pulls the ~500 MB golden qcow2 from GHCR via `skopeo` to
`~/loco-runtime/images/win98.qcow2`. If it isn't published yet (or is private),
set `GHCR_TOKEN` and re-run `bash fetch-image.sh`, or copy the qcow2 there
manually (adb push / a file manager into `~/loco-runtime/images/`).

## Run
```bash
./run-all.sh                 # boots the emulator + starts the lens server
# view the full game: a VNC viewer / Termux:X11 on 127.0.0.1:5901
# watch: point it at ws://<phone-ip>:3001/ws/lens/local
```

Just the lens (emulator already running): `./run-lens.sh`
Multiple local instances: `LENS_INSTANCES='local=127.0.0.1:5901,second=127.0.0.1:5902' ./run-lens.sh`

## Notes
- `sharp` is optional; if it fails to build, install falls back to raw frames
  and the lens still works.
- Keep VNC bound to localhost unless behind a secure transport.
- Firmware + flasher for the watch live in the repo under `m5stack-lens/`.
