# Loco Lens — Android (Termux) bundle

Run Windows 98 + Lego Loco under QEMU on your phone and drive an M5Stack
StopWatch "Loco Lens" from it — no cluster, no React app. The VNC is the
full-screen front; the lens server taps the same VNC for the watch crop.

## Install (one command)
```bash
unzip loco-lens-android.zip && cd loco-lens-android
bash install.sh
```
This installs QEMU + Node in Termux and the lens-server deps (incl. the arm64
`sharp` build).

## Provide the image
The Win98+Loco golden qcow2 is NOT in this zip (it's ~500 MB). Put it at:
```
~/loco-runtime/images/win98.qcow2
```
Pull it from GHCR (once published) or copy it over (adb push / a file manager).

## Run
```bash
./run-all.sh                 # boots the emulator + starts the lens server
# view the full game: a VNC viewer / Termux:X11 on 127.0.0.1:5901
# watch: point it at ws://<phone-ip>:3001/ws/lens/local
```

Just the lens (emulator already running): `./run-lens.sh`
Multiple local instances: `LENS_INSTANCES='local=127.0.0.1:5901,second=127.0.0.1:5902' ./run-lens.sh`

## Notes
- `sharp` is optional; if it fails to build, the lens falls back to raw frames
  and still works.
- Keep VNC bound to localhost unless behind a secure transport.
- Firmware + flasher for the watch live in the repo under `m5stack-lens/`.
