// Minimal console logger (Android bundle) — same API as the backend logger.
function fmt(level, msg, meta) {
  const m = meta && Object.keys(meta).length ? ' ' + JSON.stringify(meta) : '';
  return `[${new Date().toISOString()}] [${level}] ${msg}${m}`;
}
const logger = {
  info:  (m, meta) => console.log(fmt('INFO', m, meta)),
  warn:  (m, meta) => console.warn(fmt('WARN', m, meta)),
  error: (m, meta) => console.error(fmt('ERROR', m, meta)),
  debug: (m, meta) => { if (process.env.LENS_DEBUG) console.log(fmt('DEBUG', m, meta)); },
};
logger.createLogger = () => logger;
module.exports = logger;
module.exports.createLogger = () => logger;
