#!/usr/bin/env bash
# One-command Termux setup for the Loco Lens.
set -e
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
echo "== Loco Lens — Termux install =="
if command -v pkg >/dev/null 2>&1; then
  echo "[1/3] Installing Termux packages..."
  pkg install -y qemu-system-i386-headless qemu-utils nodejs python netcat-openbsd procps coreutils
else
  echo "WARNING: 'pkg' not found — not Termux? Skipping package install." >&2
fi
echo "[2/3] Installing lens-server node deps (fetches sharp for this arch)..."
( cd "$HERE/lens" && npm install --no-audit --no-fund )
chmod +x "$HERE"/*.sh "$HERE"/qemu/*.sh "$HERE"/qemu/image/*.sh 2>/dev/null || true
mkdir -p "$HOME/loco-runtime/run" "$HOME/loco-runtime/images" "$HOME/loco-runtime/state"
echo "[3/3] Done."
echo
echo "Next:"
echo "  1. Put your golden qcow2 at ~/loco-runtime/images/win98.qcow2"
echo "     (pull from GHCR, or copy win98-loco-golden-safe512.qcow2 there)."
echo "  2. Start the emulator:   $HERE/run-all.sh"
echo "  3. Point the M5Stack watch at ws://<phone-ip>:3001/ws/lens/local"
