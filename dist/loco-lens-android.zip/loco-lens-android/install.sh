#!/usr/bin/env bash
# One-command Termux setup for the Loco Lens.
#
#   bash install.sh              # setup + try to download the golden image
#   bash install.sh --no-image   # skip the image download
#   SKIP_IMAGE=1 bash install.sh
set -e
SELF="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Android shared storage (/storage/emulated, /sdcard) is FUSE/sdcardfs: it has
# no symlink or exec-bit support, so `npm install` fails there (EACCES symlink).
# Relocate the bundle into Termux $HOME (real ext4) and continue from there.
case "$SELF" in
  /storage/*|/sdcard/*|/mnt/*)
    DEST="$HOME/loco-lens-android"
    echo "Shared storage detected ($SELF)."
    echo ">> Copying bundle to $DEST (npm symlinks need the ext4 home fs)..."
    mkdir -p "$DEST"
    cp -a "$SELF"/. "$DEST"/
    exec bash "$DEST/install.sh" "$@"
    ;;
esac
HERE="$SELF"

WANT_IMAGE=1
for a in "$@"; do [ "$a" = "--no-image" ] && WANT_IMAGE=0; done
[ "${SKIP_IMAGE:-0}" = "1" ] && WANT_IMAGE=0

echo "== Loco Lens — Termux install =="
if command -v pkg >/dev/null 2>&1; then
  echo "[1/4] Installing Termux packages..."
  pkg install -y qemu-system-i386-headless qemu-utils nodejs python netcat-openbsd procps coreutils skopeo
else
  echo "WARNING: 'pkg' not found — not Termux? Skipping package install." >&2
fi

echo "[2/4] Installing lens-server node deps..."
if ! ( cd "$HERE/lens" && npm install --no-audit --no-fund ); then
  echo "   npm install failed; retrying without optional deps (sharp) + --no-bin-links..."
  ( cd "$HERE/lens" && npm install --no-audit --no-fund --omit=optional --no-bin-links ) || \
    echo "   WARNING: node deps incomplete — the lens may run raw-frame-only." >&2
fi

chmod +x "$HERE"/*.sh "$HERE"/qemu/*.sh "$HERE"/qemu/image/*.sh 2>/dev/null || true
mkdir -p "$HOME/loco-runtime/run" "$HOME/loco-runtime/images" "$HOME/loco-runtime/state"

echo "[3/4] Golden image..."
if [ "$WANT_IMAGE" = "1" ]; then
  if ! bash "$HERE/fetch-image.sh"; then
    echo "   Image not fetched (not published yet, or needs GHCR_TOKEN)."
    echo "   Provide it manually at ~/loco-runtime/images/win98.qcow2, or re-run:"
    echo "     bash $HERE/fetch-image.sh"
  fi
else
  echo "   Skipped (--no-image). Put the qcow2 at ~/loco-runtime/images/win98.qcow2."
fi

echo "[4/4] Done."
echo
echo "Run:   $HERE/run-all.sh"
echo "Watch: ws://<phone-ip>:3001/ws/lens/local"
